<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('https://c4.wallpaperflare.com/wallpaper/148/392/948/1920x1080-px-books-interior-design-interiors-knowledge-library-shelves-anime-pokemon-hd-art-wallpaper-preview.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            background-color: #FFFDD0;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .form-control {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .btn-primary {
            width: 100%;
            padding: 10px;
            border: none;
            background-color: #8B4513; 
            color: white;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #5C3317; 
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Edit Data Buku</h2>
        <form action="<?= base_url('/editdata/'.$data['id'])?>" method="post">
            <div class="form-group">
                <label for="judul" class="form-label">Judul</label>
                <input type="text" class="form-control" id="judul" value="<?= $data['judul'] ?>" name="judul">
            </div>
            <div class="form-group">
                <label for="penulis" class="form-label">Penulis</label>
                <input type="text" class="form-control" id="penulis" value="<?= $data['penulis'] ?>" name="penulis">
            </div>
            <div class="form-group">
                <label for="penerbit" class="form-label">Penerbit</label>
                <input type="text" class="form-control" id="penerbit" value="<?= $data['penerbit'] ?>" name="penerbit">
            </div>
            <div class="form-group">
                <label for="tahun_terbit" class="form-label">Tahun Terbit</label>
                <input type="text" class="form-control" id="tahun_terbit" value="<?= $data['tahun_terbit'] ?>" name="tahun_terbit">
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>
</body>

</html>
