<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('https://c4.wallpaperflare.com/wallpaper/148/392/948/1920x1080-px-books-interior-design-interiors-knowledge-library-shelves-anime-pokemon-hd-art-wallpaper-preview.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            background-color: #FFFDD0; 
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 600px; 
            margin: auto; 
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block; 
            font-weight: bold; 
            margin-bottom: 5px; 
        }

        .form-control {
            width: 100%; 
            padding: 8px; 
            border: 1px solid #ccc; 
            border-radius: 4px; 
            box-sizing: border-box; 
        }

        .btn-primary {
            width: 100%; 
            padding: 10px; 
            background-color: #8B4513;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #5C3317; /
        }

        .text-center {
            text-align: center;
        }

        .text-muted {
            color: #6c757d;
        }

        .mt-5 {
            margin-top: 3rem;
        }
    </style>
</head>

<body>

<section>
    <div class="container">
        <div class="text-center my-5">
        </div>
        <?php if(session()->getFlashdata('pesan')): ?>
            <div class="alert alert-warning" role="alert">
                <?= session()->getFlashdata('pesan') ?>
            </div>
        <?php endif ?>

        <?php if(session()->getFlashdata('error')): ?>
            <div class="alert alert-warning" role="alert">
                <?= session()->getFlashdata('error') ?>
            </div>
        <?php endif ?>
        <div class="card shadow-lg">
            <div class="card-body p-5">
                <h1 class="fs-4 card-title fw-bold mb-4">Login</h1>
                <form action="<?= base_url('/login')?>" method="POST" class="needs-validation" novalidate autocomplete="off">
                    <div class="form-group">
                        <label class="form-label text-muted" for="username">User Name</label>
                        <input id="username" type="text" class="form-control" name="username" required>
                        <div class="invalid-feedback">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label text-muted" for="email">E-Mail Address</label>
                        <input id="email" type="email" class="form-control" name="email" value="" required autofocus>
                        <div class="invalid-feedback">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label text-muted" for="password">Password</label>
                        <input id="password" type="password" class="form-control" name="password" required>
                        <div class="invalid-feedback">
                        </div>
                    </div>

                    <div class="d-flex align-items-center">
                        <button type="submit" class="btn btn-primary">
                            Login
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <div class="text-center mt-5 text-muted">
            Copyright &copy; 2024 &mdash; Aldira Putri Sholeha
        </div>
    </div>
</section>

</body>
</html>
