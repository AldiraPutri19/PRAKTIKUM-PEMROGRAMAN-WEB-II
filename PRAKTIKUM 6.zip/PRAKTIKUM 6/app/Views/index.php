<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <style>
        *,
        *::before,
        *::after {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-image: url('https://c4.wallpaperflare.com/wallpaper/148/392/948/1920x1080-px-books-interior-design-interiors-knowledge-library-shelves-anime-pokemon-hd-art-wallpaper-preview.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            max-width: 960px;
            margin: 20px;
            padding: 20px;
            background-color: #FFFDD0; 
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

        .header h1 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .btn-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 20px;
        }

        .btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 16px;
            margin-top: 10px;
            text-align: center;
            width: 150px; 
        }

        .btn.add-data-btn {
            background-color: #8B4513; 
        }

        .btn.add-data-btn:hover {
            background-color: #5C3317; 
        }

        .btn.logout {
            background-color: #000000; 
        }

        .btn.logout:hover {
            background-color: #333333; 
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .book-list {
            margin-top: 20px;
        }

        .book-list h2 {
            font-size: 20px;
            margin-bottom: 10px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .table th, .table td {
            padding: 8px;
            border: 1px solid #ccc;
            text-align: left;
        }

        .table th {
            background-color: #212529;
            color: #fff;
        }

        .table td a {
            display: inline-block;
            text-decoration: none;
            padding: 6px 12px;
            margin-right: 4px;
            border-radius: 4px;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }

        .table td a.btn-warning {
            background-color: #ffc107;
            color: #212529;
        }

        .table td a.btn-danger {
            background-color: #dc3545;
            color: #fff;
        }

        .table td a.btn-success {
            background-color: #28a745;
            color: #fff;
        }

        .table td a:hover {
            opacity: 0.8;
        }

        .table form button {
            display: inline-block;
            text-decoration: none;
            padding: 6px 12px;
            border-radius: 4px;
            font-size: 14px;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .table form button:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Selamat Datang di Perpustakaan</h1>
        </div>

        <!-- create list of books -->
        <div class="book-list">
            <h2>Daftar Buku</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Judul</th>
                        <th>Penulis</th>
                        <th>Penerbit</th>
                        <th>Tahun Terbit</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($data as $row): ?>
                        <tr>
                            <td><?= $row['judul'] ?></td>
                            <td><?= $row['penulis'] ?></td>
                            <td><?= $row['penerbit'] ?></td>
                            <td><?= $row['tahun_terbit'] ?></td>
                            <td>
                                <a href="<?= base_url('/editdata/'.$row['id']) ?>" class="btn-warning">Edit</a>
                                <form action="<?= base_url('/hapusdata/'.$row['id'])?>" style="display:inline" method="post">
                                    <input type="hidden" name="_method" value="DELETE">
                                    <button class="btn-danger" type="submit" onclick="return confirm('Apakah anda yakin?')">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>

        <div class="btn-container">
            <a href="<?= base_url('/tambahdata')?>" class="btn add-data-btn">Tambah Data</a>
            <a href="<?= base_url('/logout')?>" class="btn logout">Logout</a>
        </div>
    </div>
</body>
</html>
