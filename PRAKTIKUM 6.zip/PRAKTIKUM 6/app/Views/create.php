<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data</title>
    <style>
        body {
            background-image: url('https://c4.wallpaperflare.com/wallpaper/148/392/948/1920x1080-px-books-interior-design-interiors-knowledge-library-shelves-anime-pokemon-hd-art-wallpaper-preview.jpg');
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .form-container {
            background-color: #FFFDD0; 
            padding: 2rem;
            border-radius: 0.5rem;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .form-container h2 {
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .form-container .form-group {
            margin-bottom: 1rem;
        }

        .form-container label {
            display: block;
            margin-bottom: 0.5rem;
        }

        .form-container input {
            width: calc(100% - 1rem);
            padding: 0.5rem;
            border: 1px solid #ced4da;
            border-radius: 0.25rem;
            box-sizing: border-box;
        }

        .form-container button {
            width: 100%;
            padding: 0.5rem;
            border: none;
            border-radius: 0.25rem;
            cursor: pointer;
            margin-top: 0.5rem; 
            text-align: center;
            text-decoration: none;
            transition: background-color 0.3s ease; 
        }

        .form-container .btn-tambah {
            background-color: #8B4513; 
            color: #fff;
        }

        .form-container .btn-tambah:hover {
            background-color: #5C3317; 
        }

        .form-container .btn-kembali {
            background-color: #000; 
            color: #fff;
        }

        .form-container .btn-kembali:hover {
            background-color: #333; 
        }
    </style>
</head>

<body>
    <div class="form-container">
        <h2>Tambah Data Buku</h2>
        <form action="<?= base_url('/tambahdata')?>" method="post">
            <div class="form-group">
                <label for="judul" class="form-label">Judul</label>
                <input name="judul" type="text" class="form-control" id="judul">
            </div>
            <div class="form-group">
                <label for="penulis" class="form-label">Penulis</label>
                <input type="text" class="form-control" id="penulis" name="penulis">
            </div>
            <div class="form-group">
                <label for="penerbit" class="form-label">Penerbit</label>
                <input type="text" class="form-control" id="penerbit" name="penerbit">
            </div>
            <div class="form-group">
                <label for="tahun_terbit" class="form-label">Tahun Terbit</label>
                <input type="number" min="1800" max="2024" class="form-control" id="tahun_terbit" name="tahun_terbit">
            </div>
            <button type="submit" class="button btn-tambah">Tambah</button>
        </form>
        <button onclick="history.back()" class="button btn-kembali">Kembali</button>
    </div>
</body>

</html>
