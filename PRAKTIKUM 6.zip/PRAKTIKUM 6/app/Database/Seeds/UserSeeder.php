<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use App\Models\UserModel;

class UserSeeder extends Seeder
{
    public function run()
    {
        $model = new UserModel();

        //panggil methdo insert
        $model->insert([
            "username"=> "aldira",
            "email"=> "aldira10@gmail.com",
            "password" => password_hash("100904",PASSWORD_DEFAULT),
        ]);
    }
}
